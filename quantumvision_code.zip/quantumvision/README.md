# QuantumVision

**Hybrid Quantum Deep Transfer Learning based Facial Emotion Recognition for Smart-City Surveillance**

An academic implementation of *Chapter 12 – A Conceptual Framework for Hybrid Quantum Deep Transfer Learning for
Emotion-Aware Surveillance in Next-Generation Smart Cities*.

> **Limitations.** Facial emotion predictions are probabilistic estimates of facial expression. They do not establish
> a person's mental state, intent or dangerousness. The quantum circuit runs on a **classical simulator**; **no quantum
> advantage is claimed** unless the project's own measured benchmarks show it. Alerts are statistical, group-level
> anomalies that require **human review**.

## Pipeline

```
image / camera -> face detection -> preprocessing -> ResNet50 (ImageNet transfer learning, 2048-d)
  -> dimensionality reduction (Linear 2048 -> n_qubits) -> angle encoding (R_y)
  -> variational quantum circuit (RX/RY/RZ + CNOT ring, PennyLane) -> Pauli-Z expectation values
  -> fusion (concat classical 256-d + quantum n-d) -> dense + softmax -> 7 emotions -> analytics / anomaly alerts
```

Emotions: Angry, Disgust, Fear, Happy, Sad, Surprise, Neutral. Dataset: FER2013.

Models compared (identical frozen ResNet50 features, splits, optimiser and seeds):

| Model | Head |
|---|---|
| A  Classical baseline | Linear(2048,256) → ReLU → Dropout → Linear(256,7) |
| A′ Control | same, with a classical `tanh(Linear(n,n))` where the VQC would be (shows whether any gain is "quantum" or just "extra parameters") |
| B  Hybrid | reduce → R_y encoding → VQC → ⟨Z⟩ → concat with classical features → Linear(7) |

## Quick start

### 1. Environment (Windows PowerShell shown; Linux/macOS use `source .venv/bin/activate`)

```powershell
python -m venv .venv ; .venv\Scripts\activate
pip install torch torchvision --index-url https://download.pytorch.org/whl/cu121   # CUDA build for an NVIDIA GPU
pip install -r requirements.txt
copy .env.example .env      # then edit JWT_SECRET / ADMIN_PASSWORD
```

### 2. Data (FER2013 as a zip of image folders, or fer2013.csv)

```powershell
python -m ml.preprocessing.zip_to_folders --zip archive.zip          # -> data/fer2013/{train,validation,test}/<emotion>/
# or: python -m ml.preprocessing.csv_to_folders --csv fer2013.csv
python scripts/fetch_face_model.py                                    # optional YuNet face model (else Haar cascade)
```

### 3. Train and compare (needs internet once for the ImageNet ResNet50 weights)

```powershell
python extract_features.py --device cuda                               # caches frozen ResNet50 features (once)
python run_experiments.py --seeds 42 43 44 --device cuda               # trains A, A', B for each seed + evaluates on test
python compare.py                                                      # writes ml/models/comparison.{json,md}
```

Fine-tuning (`layer4`/full network) is available with `--mode fine_tuning` in `train_classical.py` / `train_hybrid.py`.
Everything shown in the app's **Model Performance** page comes from `comparison.json`; if it does not exist the page says so.

### 4. Run the app

```powershell
uvicorn backend.app.main:app --reload --port 8000     # API + WebSocket, docs at /docs
cd frontend ; npm install ; npm run dev                # http://localhost:5173
```

Login: the `ADMIN_EMAIL` / `ADMIN_PASSWORD` from `.env` (defaults `admin@quantumvision.local` / `admin123` – change them).
Roles: `ADMIN` (everything, users, cameras), `OPERATOR` (acknowledge/resolve alerts), `VIEWER` (read-only).

### 5. Docker (PostgreSQL + backend + frontend)

```bash
docker compose up --build        # app at http://localhost:8080 ; mount trained models in ./ml/models
```

## Application pages

Dashboard · Live Surveillance (webcam or video file) · Image Analysis (multi-face) · Emotion Analytics ·
Alerts (NEW/ACKNOWLEDGED/RESOLVED, LOW→CRITICAL, operator notes) · Quantum Circuit · Model Performance · Cameras · Settings.

## Emotional-anomaly alerts

No single emotion is treated as dangerous. An alert is raised only for a **group-level, sustained** shift of
Fear/Surprise/Angry share relative to the camera's own rolling baseline (≥3 faces, ≥8 s inside a 20 s window,
≥60 % of frames elevated, 60 s cooldown). Details: [docs/architecture.md](docs/architecture.md).

## Testing

```bash
python -m pytest -q        # 59 tests (quantum circuit checked against an independent numpy state-vector, API, alerts, ...)
cd frontend && npm run build
```

## Honest status

* All code paths were verified end-to-end in a browser using a **randomly initialised smoke-test checkpoint**; the app
  labels such models as "not trained" and their predictions are meaningless.
* **No accuracy numbers are reported in this repository.** They must be produced by running the training commands above
  on your own machine; the comparison tooling reports mean ± std over seeds and an exact McNemar test, and its summary
  sentence cannot claim an advantage the statistics do not support.

## Documentation

[docs/architecture.md](docs/architecture.md) · [docs/ml_pipeline.md](docs/ml_pipeline.md) ·
[docs/quantum_pipeline.md](docs/quantum_pipeline.md) · [docs/api.md](docs/api.md) ·
[docs/database.md](docs/database.md) · [docs/deployment.md](docs/deployment.md)
