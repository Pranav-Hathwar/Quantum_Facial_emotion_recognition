"""Torch datasets/loaders on top of the framework-agnostic FER2013 folder dataset."""
from __future__ import annotations

from pathlib import Path

import numpy as np
import torch
from torch.utils.data import DataLoader, Dataset, TensorDataset

from ml.preprocessing.dataset import FER2013Dataset
from ml.preprocessing.image_preprocessor import preprocess_face


class FERImageTensorDataset(Dataset):
    """(3,S,S) ImageNet-normalised float tensor + label. Optional random horizontal flip for training."""

    def __init__(self, root: Path, split: str, image_size: int = 224, hflip: bool = False, limit: int | None = None):
        self.base = FER2013Dataset(root, split)
        if limit is not None:  # deterministic class-balanced-ish subset for smoke tests
            step = max(1, len(self.base.samples) // limit)
            self.base.samples = self.base.samples[::step][:limit]
        self.size, self.hflip = image_size, hflip

    def __len__(self) -> int:
        return len(self.base)

    def __getitem__(self, i: int):
        img, label = self.base[i]
        if self.hflip:
            img = np.ascontiguousarray(img[:, ::-1])
        return torch.from_numpy(preprocess_face(img, self.size)), label


def feature_loader(features: np.ndarray, labels: np.ndarray, batch_size: int, shuffle: bool) -> DataLoader:
    ds = TensorDataset(torch.from_numpy(features.astype(np.float32)), torch.from_numpy(labels.astype(np.int64)))
    return DataLoader(ds, batch_size=batch_size, shuffle=shuffle, drop_last=False)
